import React, { useState } from 'react';
import './reg.css';

function RegistrationForm() {
    const [formData, setFormData] = useState({
        username: '',
        firstName: '',
        lastName: '',
        dob: '',
        gender: '',
        password: '',
        confirmPassword: '',
        passwordError: '',
        confirmPasswordError: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        let passwordError = formData.passwordError;
        let confirmPasswordError = formData.confirmPasswordError;

        if (name === 'password') {
            const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,}$/;
            if (!passwordRegex.test(value)) {
                passwordError = 'Password must contain at least 8 characters, including 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character';
            } else {
                passwordError = '';
            }
        }

        if (name === 'confirmPassword') {
            if (value !== formData.password) {
                confirmPasswordError = 'Passwords do not match';
            } else {
                confirmPasswordError = '';
            }
        }

        setFormData(prevState => ({
            ...prevState,
            [name]: value,
            passwordError: passwordError,
            confirmPasswordError: confirmPasswordError
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(formData);
    };

    return (
        <div className="container">
            <h2>Registration Form</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="username">Username:</label>
                    <input type="text" id="username" name="username" placeholder="Enter user name" value={formData.username} onChange={handleChange} required />
                    <span className="error-message" id="usernameError"></span>
                </div>
                <div>
                    <label htmlFor="firstName">First Name:</label>
                    <input type="text" id="firstName" name="firstName" placeholder="Enter your first name" value={formData.firstName} onChange={handleChange} required />
                </div>
                <div>
                    <label htmlFor="lastName">Last Name:</label>
                    <input type="text" id="lastName" name="lastName" placeholder="Enter your last name" value={formData.lastName} onChange={handleChange} required />
                </div>
                <div>
                    <label htmlFor="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="dob" value={formData.dob} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Gender:</label>
                    <input type="radio" id="male" name="gender" value="Male" checked={formData.gender === 'Male'} onChange={handleChange} required />
                    <label htmlFor="male">Male</label>
                    <input type="radio" id="female" name="gender" value="Female" checked={formData.gender === 'Female'} onChange={handleChange} required />
                    <label htmlFor="female">Female</label>
                </div>
                <div>
                    <label htmlFor="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" value={formData.password} onChange={handleChange} required />
                    <span className="error-message">{formData.passwordError}</span>
                </div>
                <div>
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Retype your password" value={formData.confirmPassword} onChange={handleChange} required />
                    <span className="error-message">{formData.confirmPasswordError}</span>
                </div>
                <button type="submit" id="submitButton" disabled={!formData.username || !formData.firstName || !formData.lastName || !formData.dob || !formData.gender || !formData.password || !formData.confirmPassword || formData.passwordError || formData.confirmPasswordError}>Submit</button>
            </form>
            <p>Already have an account? <a href="login.html">Login here</a></p>
        </div>
    );
}

export default RegistrationForm;


