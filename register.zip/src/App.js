import React from 'react';
import RegistrationForm from './RegistrationPage';
 
function App() {
  return (
    <div>
      <RegistrationForm />
    </div>
  );
}
export default App;